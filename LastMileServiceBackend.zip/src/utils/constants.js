const DATE_FORMAT = "YYYY-MM-DD HH:mm";
const API_PREFIX = "/api";

module.exports = {
  DATE_FORMAT,
  API_PREFIX,
};
